from setuptools import setup, find_packages

setup(
    name="nyapkg",
    version="5.0.1",
    author="aayush-jha",
    description="abhi bnaya h using GHA",
    packages=find_packages(),
    install_requires=[
        # List dependencies, e.g., 'numpy', 'pandas'
    ],
)
