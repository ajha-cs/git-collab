## MyPackage
A simple Python package for greeting people.

## Installation
```bash
pip install nyapkg
